version '1.0.0'
author 'GIIIPFEL'
description 'Made by the weebigste Weeb auf ERDEN.'
repository 'https://github.com/citizenfx/cfx-server-data'

files {
    'index.html',
    'music.mp3',
}

loadscreen 'index.html'

fx_version 'bodacious'
game 'gta5'